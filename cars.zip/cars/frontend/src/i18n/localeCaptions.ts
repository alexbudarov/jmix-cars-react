const localeCaptions = {
  en: "English"
};

export default localeCaptions;
