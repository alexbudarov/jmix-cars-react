import { menuItems } from "@haulmont/jmix-react-ui";
import "./app/home/HomePage";
